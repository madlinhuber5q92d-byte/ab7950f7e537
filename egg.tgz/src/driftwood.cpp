// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply driftwood migrations\n", stdout);
  return lionss_run_workload("driftwood");
}
