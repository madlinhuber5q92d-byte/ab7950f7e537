// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Replay order book"); }
int main(){
  announce();
  return lionss_run_workload("orderbook_replay");
}
