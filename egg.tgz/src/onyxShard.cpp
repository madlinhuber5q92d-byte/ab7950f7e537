// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Balance onyx shards\n", stdout);
  return lionss_run_workload("onyxShard");
}
