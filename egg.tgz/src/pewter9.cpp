// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cast pewter components"); }
int main(){
  announce();
  return lionss_run_workload("pewter9");
}
