// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Resample via sinc\n", stdout);
  return lionss_run_workload("SincResample");
}
